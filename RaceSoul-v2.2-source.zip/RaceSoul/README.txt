RaceSoul v2.1 - 7 linh hồn kiểu Glitchtale (add-on cho RaceFantasy)

Build:   mvn clean package        -> target/RaceSoul.jar
Cài:     bỏ RaceSoul.jar vào plugins/ (chạy cùng RaceFantasy), restart server
Lệnh:    /linhhon  (alias /soul, /hl)  - xem linh hồn của mình (chưa có thì random)
         /linhhon hate                 - chuyển qua lại Căm Hận <-> linh hồn gốc (cần mở khoá)
         /linhhon reset <tên>          - admin: xoá và random lại linh hồn
         /linhhon unlock <tên>         - admin: mở khoá linh hồn ẩn Căm Hận (đen)
         /linhhon lock <tên>           - admin: khoá lại
Linh hồn random khi vào server (không tự chọn, không đổi). Căm Hận không bao giờ random trúng.
Số liệu chỉnh trong plugins/RaceSoul/config.yml
Kỹ năng chủ động: Shift + chuột phải bằng tay không (riêng Tím là bị động).
