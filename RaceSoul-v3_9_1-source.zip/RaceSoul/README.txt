RaceSoul v3.0 - 7 linh hồn kiểu Glitchtale (add-on cho RaceFantasy)

Build:   mvn clean package        -> target/RaceSoul.jar
Cài:     bỏ RaceSoul.jar vào plugins/ (chạy cùng RaceFantasy), restart server
Lệnh:    /linhhon  (alias /soul, /hl)  - xem linh hồn của mình (chưa có thì random)
         /linhhon hate                 - chuyển qua lại Căm Hận <-> linh hồn gốc (cần mở khoá)
         /linhhon reset <tên>          - admin: xoá và random lại linh hồn
         /linhhon unlock <tên>         - admin: mở khoá linh hồn ẩn Căm Hận (đen)
         /linhhon lock <tên>           - admin: khoá lại
Linh hồn random khi vào server (không tự chọn, không đổi). Căm Hận không bao giờ random trúng.
Số liệu chỉnh trong plugins/RaceSoul/config.yml
Từ v3.0: không còn kỹ năng chủ động. Mỗi linh hồn có 1 bị động + chỉ số nền (mục stats) + cộng hưởng với tộc RaceFantasy (mục synergy).

v3.3: Linh hồn Đỏ (Quyết Tâm) có kỹ năng SAVE/LOAD:
         /linhhon save   - lưu vị trí + máu + thức ăn (hiện ngôi sao tại điểm lưu)
         /linhhon load   - quay lại điểm đã lưu, hồi máu lên mức đã lưu
       Chỉnh trong config.yml mục red.save-load.

v3.4: Đỏ tự nhận Ngôi sao SAVE (nether star, không rơi/không cất rương, giữ khi chết).
         Chuột phải = SAVE; chuột phải lần nữa = LOAD; Shift+chuột phải = SAVE lại.
         /linhhon item - nhận lại sao nếu mất. Tắt phát item: red.save-load.give-item: false

v3.5: Hiệu ứng quay linh hồn: tên các linh hồn nhảy liên tục trên màn hình, chậm dần rồi dừng ở linh hồn nhận được.
       Tắt bằng roll-animation: false trong config.yml.

v3.5.1: Buff Cam (+15% cận chiến, +1.5 sát thương nền) và Vàng (+25% đạn bắn, +15% tốc độ đánh, +5% tốc độ chạy).

v3.6: Kỹ năng đặc biệt cho Cam, Vàng, Lục, Lam, Xanh ngọc (chỉnh trong config.yml, mỗi màu):
       Cam  - Xung Phong: đánh liên tiếp, đòn thứ 5 là Xung Kích (+4 sát thương, hất tung)
       Vàng - Phán Quyết: bắn trúng cùng 1 mục tiêu 3 lần liên tiếp, phát cuối +5 sát thương và phát sáng
       Lục  - Hào Quang: người chơi trong 8 block được hồi 1 máu mỗi 3s
       Lam  - Khiên Phản Đòn: giơ khiên đỡ đòn cận chiến thì phản 40% sát thương và đẩy lùi
       Ngọc - Tĩnh Tâm: đứng yên 3s: giảm 25% sát thương nhận, đòn cận chiến kế tiếp +40%

v3.6.1: Buff mạnh skill Cam/Vàng/Lục/Lam/Xanh ngọc (xem config.yml).

v3.7: Đổi lại toàn bộ skill đặc biệt của Cam, Vàng, Lục, Lam, Xanh ngọc (dễ kích hoạt hơn, bỏ Tĩnh Tâm):
       Cam  - Xung Phong (đánh khi sprint: +5 sát thương, hất xa), Khải Hoàn (hạ gục: hồi máu + Speed)
       Vàng - Phán Quyết (đạn trúng: +8 sát thương, phát sáng), Đền Tội (đánh kẻ vừa đánh mình +30%)
       Lục  - Hào Quang (hồi người xung quanh), Cứu Rỗi (ai gần sắp gục được Hồi Phục + Máu Ảo)
       Lam  - Phản Chấn (bị đánh cận chiến phản 35%, giơ khiên 75%), giảm 25% sát thương đạn
       Ngọc - Sương Giá (mỗi đòn +1 tầng lạnh, đủ 4 tầng đóng băng 2s), giảm 30% sát thương từ kẻ đang lạnh

v3.7.1: Nerf Lam: Phản Chấn hồi 4s, phản 30% (khiên 60%), giảm đạn 20%.

v3.7.2: Nerf Lục (Hào Quang hồi 0.5 tim/3s bán kính 8; Cứu Rỗi hồi 60s, Hồi Phục II + Máu Ảo 2 tim). Lam trả về số của v3.7.0.

v3.7.3: Nerf Lam: Phản Chấn hồi 4s, phản 30% (khiên 60%), giảm đạn 20%.

v3.8: Buff mạnh Căm Hận (Đen): chỉ số nền +6 máu, +2 sát thương, +10% tốc độ đánh, +3 giáp, +20% kháng đẩy;
       giảm 30% sát thương nhận, hút 30% máu; Lời Nguyền (đánh thường gây Héo Mòn II 4s); Nuốt Chửng (hạ gục hồi 3 tim + Máu Ảo).

v3.9: Buff mạnh Đỏ (ngang Đen, kém xíu): nền +6 máu, +1.5 sát thương, +2 giáp, +10% kháng đẩy;
       Quyết Tâm kích hoạt khi dưới 40% máu, kéo dài 10s, hồi 2 máu/giây, +3 sát thương, hồi 90s;
       thêm Không Chịu Gục: đòn chí mạng thì sống sót với 1 tim (hồi 300s) và kích hoạt Quyết Tâm.

v3.9.1: Hạ nhẹ Đỏ: nền +4 máu (trước +6), hồi chiêu Quyết Tâm 120s (trước 90s).
