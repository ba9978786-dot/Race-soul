package com.racesoul;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Kỹ năng đặc biệt (bị động, dễ kích hoạt) cho Cam, Vàng, Lục, Lam, Xanh ngọc.
 *  - Cam  : Xung Phong (đánh khi đang chạy nhanh: đòn mạnh + hất xa) / Khải Hoàn (hạ gục: hồi máu + tăng tốc)
 *  - Vàng : Phán Quyết (đạn bắn trúng: đòn mạnh + phát sáng) / Đền Tội (đánh kẻ vừa đánh mình: +sát thương)
 *  - Lục  : Hào Quang (hồi máu người xung quanh) / Cứu Rỗi (ai sắp gục gần bạn được hồi sinh lực + khiên máu)
 *  - Lam  : Phản Chấn (bị đánh cận chiến thì phản lại, giơ khiên phản mạnh hơn) / giảm sát thương đạn bắn
 *  - Ngọc : Sương Giá (mỗi đòn đánh cộng 1 tầng lạnh, đủ tầng thì đóng băng) / giảm sát thương từ kẻ đang bị lạnh
 */
public final class SoulSkills implements Listener {
    private final SoulPlugin plugin;

    private static final class Cold {
        int n;
        long expire;
        long immuneUntil;
    }

    /** Vàng: kẻ nào vừa đánh mình, và lúc nào. */
    private final Map<UUID, Map<UUID, Long>> yellowFoes = new HashMap<>();
    /** Ngọc: tầng lạnh trên từng mục tiêu. */
    private final Map<UUID, Cold> colds = new HashMap<>();

    public SoulSkills(SoulPlugin plugin) {
        this.plugin = plugin;
        long auraPeriod = Math.max(1, plugin.getConfig().getInt("green.aura-interval-seconds", 2)) * 20L;
        Bukkit.getScheduler().runTaskTimer(plugin, this::tickAura, auraPeriod, auraPeriod);
        Bukkit.getScheduler().runTaskTimer(plugin, this::purge, 200L, 200L);
    }

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        yellowFoes.remove(e.getPlayer().getUniqueId());
        colds.remove(e.getPlayer().getUniqueId());
    }

    /** Kẻ gây sát thương thật sự (nếu là đạn thì lấy người bắn). */
    private static LivingEntity source(Entity damager) {
        if (damager instanceof Projectile pr && pr.getShooter() instanceof LivingEntity sh) return sh;
        if (damager instanceof LivingEntity le) return le;
        return null;
    }

    // ===================== GÂY sát thương: Cam / Vàng / Xanh ngọc =====================

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDealDamage(EntityDamageByEntityEvent e) {
        Player p;
        boolean ranged = false;
        if (e.getDamager() instanceof Player direct) {
            p = direct;
            if (e.getCause() != DamageCause.ENTITY_ATTACK) return; // bỏ quét kiếm, gai...
        } else if (e.getDamager() instanceof Projectile pr && pr.getShooter() instanceof Player shooter) {
            p = shooter;
            ranged = true;
        } else {
            return;
        }
        Soul s = plugin.getSoul(p);
        if (s == null) return;
        if (!(e.getEntity() instanceof LivingEntity victim) || !Util.canTarget(p, victim)) return;

        if (s == Soul.ORANGE && !ranged) orangeCharge(p, victim, e);
        else if (s == Soul.YELLOW) yellowStrike(p, victim, e, ranged);
        else if (s == Soul.CYAN && !ranged) cyanFrost(p, victim);
        else if (s == Soul.HATE && !ranged) hateCurse(victim);
    }

    /** Cam - Xung Phong: đánh khi đang chạy nhanh thì gây thêm sát thương và hất kẻ địch ra xa. */
    private void orangeCharge(Player p, LivingEntity victim, EntityDamageByEntityEvent e) {
        if (!p.isSprinting()) return;
        if (plugin.cdLeftMs(p, "orange-charge") > 0) return;
        plugin.setCd(p, "orange-charge", Math.max(1, cfg().getInt("orange.charge-cooldown-seconds", 5)));
        e.setDamage(e.getDamage() + cfg().getDouble("orange.charge-damage", 5.0));
        Vector dir = victim.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
        if (dir.lengthSquared() > 0.0001) {
            dir.normalize().multiply(cfg().getDouble("orange.charge-knockback", 1.2)).setY(0.4);
            victim.setVelocity(victim.getVelocity().add(dir));
        }
        victim.getWorld().spawnParticle(Particle.CRIT, victim.getLocation().add(0, 1, 0), 25, 0.4, 0.5, 0.4, 0.3);
        victim.getWorld().playSound(victim.getLocation(), Sound.ENTITY_PLAYER_ATTACK_STRONG, 1f, 0.7f);
        p.sendActionBar(Component.text("XUNG PHONG!", NamedTextColor.GOLD));
    }

    /** Cam - Khải Hoàn: hạ gục sinh vật thì hồi máu và tăng tốc. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onKill(EntityDeathEvent e) {
        colds.remove(e.getEntity().getUniqueId());
        if (e.getEntity() instanceof ArmorStand) return;
        Player p = e.getEntity().getKiller();
        if (p == null || p.isDead()) return;
        Soul ks = plugin.getSoul(p);
        if (ks == Soul.HATE) {
            hateFeast(p);
            return;
        }
        if (ks != Soul.ORANGE) return;
        double heal = cfg().getDouble("orange.kill-heal", 4.0);
        if (heal > 0) {
            double max = p.getAttribute(Attribute.MAX_HEALTH).getValue();
            p.setHealth(Math.min(max, p.getHealth() + heal));
        }
        int secs = cfg().getInt("orange.kill-speed-seconds", 4);
        int lvl = cfg().getInt("orange.kill-speed-level", 2);
        if (secs > 0 && lvl > 0) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, secs * 20, lvl - 1, false, true, true));
        }
        p.getWorld().spawnParticle(Particle.HEART, p.getLocation().add(0, 2, 0), 3, 0.3, 0.2, 0.3, 0);
        p.sendActionBar(Component.text("Khải Hoàn!", NamedTextColor.GOLD));
    }

    /**
     * Vàng - Phán Quyết: đạn bắn trúng gây thêm sát thương + phát sáng (có hồi chiêu).
     * Vàng - Đền Tội: đánh kẻ vừa đánh mình trong vài giây gần đây thì +% sát thương.
     */
    private void yellowStrike(Player p, LivingEntity victim, EntityDamageByEntityEvent e, boolean ranged) {
        Map<UUID, Long> foes = yellowFoes.get(p.getUniqueId());
        if (foes != null) {
            Long t = foes.get(victim.getUniqueId());
            long keep = cfg().getInt("yellow.retaliate-seconds", 8) * 1000L;
            if (t != null && System.currentTimeMillis() - t <= keep) {
                e.setDamage(e.getDamage() * (1 + cfg().getDouble("yellow.retaliate-bonus", 0.30)));
                victim.getWorld().spawnParticle(Particle.CRIT, victim.getLocation().add(0, 1, 0), 8, 0.3, 0.4, 0.3, 0.2);
            }
        }
        if (!ranged || plugin.cdLeftMs(p, "yellow-verdict") > 0) return;
        plugin.setCd(p, "yellow-verdict", Math.max(1, cfg().getInt("yellow.verdict-cooldown-seconds", 4)));
        e.setDamage(e.getDamage() + cfg().getDouble("yellow.verdict-damage", 8.0));
        int glow = cfg().getInt("yellow.verdict-glow-seconds", 5);
        if (glow > 0) {
            victim.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, glow * 20, 0, false, false, false));
        }
        victim.getWorld().spawnParticle(Particle.CRIT, victim.getLocation().add(0, 1, 0), 30, 0.4, 0.6, 0.4, 0.4);
        victim.getWorld().playSound(victim.getLocation(), Sound.ITEM_TRIDENT_THUNDER, 0.6f, 1.4f);
        p.sendActionBar(Component.text("PHÁN QUYẾT!", NamedTextColor.YELLOW));
    }

    /** Xanh ngọc - Sương Giá: mỗi đòn cận chiến +1 tầng lạnh (càng nhiều càng chậm), đủ tầng thì đóng băng. */
    private void cyanFrost(Player p, LivingEntity victim) {
        long now = System.currentTimeMillis();
        int need = Math.max(2, cfg().getInt("cyan.frost-hits", 4));
        long window = cfg().getInt("cyan.frost-window-seconds", 6) * 1000L;
        Cold c = colds.computeIfAbsent(victim.getUniqueId(), k -> new Cold());
        if (now > c.expire) c.n = 0;
        if (now < c.immuneUntil) return; // vừa bị đóng băng xong, miễn nhiễm một lúc (chống khoá cứng)
        c.n++;
        c.expire = now + window;
        victim.getWorld().spawnParticle(Particle.SNOWFLAKE, victim.getLocation().add(0, 1, 0), 10, 0.3, 0.5, 0.3, 0.02);
        if (c.n >= need) {
            c.n = 0;
            int freeze = Math.max(1, cfg().getInt("cyan.frost-freeze-seconds", 2));
            c.immuneUntil = now + cfg().getInt("cyan.frost-immune-seconds", 6) * 1000L;
            victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, freeze * 20, 6, false, true, true));
            victim.getWorld().spawnParticle(Particle.SNOWFLAKE, victim.getLocation().add(0, 1, 0), 40, 0.4, 0.7, 0.4, 0.05);
            victim.getWorld().playSound(victim.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 1.5f);
            p.sendActionBar(Component.text("ĐÓNG BĂNG!", NamedTextColor.AQUA));
        } else {
            victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, Math.min(3, c.n - 1), false, true, true));
            p.sendActionBar(Component.text("Sương Giá " + c.n + "/" + need, NamedTextColor.AQUA));
        }
    }

    /** Đen - Lời Nguyền: mỗi đòn đánh thường khiến mục tiêu bị Héo Mòn (Wither). */
    private void hateCurse(LivingEntity victim) {
        int secs = cfg().getInt("hate.wither-seconds", 4);
        int lvl = cfg().getInt("hate.wither-level", 2);
        if (secs <= 0 || lvl <= 0) return;
        victim.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, secs * 20, lvl - 1, false, true, true));
        victim.getWorld().spawnParticle(Particle.SMOKE, victim.getLocation().add(0, 1, 0), 10, 0.3, 0.5, 0.3, 0.02);
    }

    /** Đen - Nuốt Chửng: hạ gục sinh vật thì hồi máu và nhận Máu Ảo. */
    private void hateFeast(Player p) {
        double heal = cfg().getDouble("hate.kill-heal", 6.0);
        if (heal > 0) {
            double max = p.getAttribute(Attribute.MAX_HEALTH).getValue();
            p.setHealth(Math.min(max, p.getHealth() + heal));
        }
        int lvl = cfg().getInt("hate.kill-absorption-level", 1);
        int secs = cfg().getInt("hate.kill-absorption-seconds", 8);
        if (lvl > 0 && secs > 0) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, secs * 20, lvl - 1, false, true, true));
        }
        p.getWorld().spawnParticle(Particle.SMOKE, p.getLocation().add(0, 1, 0), 20, 0.4, 0.7, 0.4, 0.03);
        p.sendActionBar(Component.text("Nuốt Chửng!", NamedTextColor.DARK_GRAY));
    }

    // ===================== NHẬN sát thương bởi thực thể: Lam / Vàng / Xanh ngọc =====================

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTakeHit(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        Soul s = plugin.getSoul(p);
        if (s != Soul.BLUE && s != Soul.YELLOW && s != Soul.CYAN) return;
        LivingEntity atk = source(e.getDamager());
        if (atk == null || atk.equals(p)) return;

        if (s == Soul.YELLOW) {
            yellowFoes.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>())
                    .put(atk.getUniqueId(), System.currentTimeMillis());
        } else if (s == Soul.CYAN) {
            Cold c = colds.get(atk.getUniqueId());
            if (c != null && c.n > 0 && System.currentTimeMillis() <= c.expire) {
                double red = Math.max(0, Math.min(0.9, cfg().getDouble("cyan.frost-damage-reduction", 0.30)));
                e.setDamage(e.getDamage() * (1 - red));
            }
        } else {
            blueReflect(p, atk, e);
        }
    }

    /** Lam - Phản Chấn: bị đánh cận chiến thì phản lại một phần sát thương (giơ khiên thì phản nhiều hơn). */
    private void blueReflect(Player p, LivingEntity atk, EntityDamageByEntityEvent e) {
        if (e.getCause() != DamageCause.ENTITY_ATTACK || !Util.canTarget(p, atk)) return;
        if (plugin.cdLeftMs(p, "blue-reflect") > 0) return;
        double ratio = p.isBlocking()
                ? cfg().getDouble("blue.reflect-block-ratio", 0.75)
                : cfg().getDouble("blue.reflect-ratio", 0.35);
        double amount = e.getDamage() * ratio;
        if (amount <= 0) return;
        plugin.setCd(p, "blue-reflect", Math.max(1, cfg().getInt("blue.reflect-cooldown-seconds", 1)));

        atk.damage(amount, p);
        Vector dir = atk.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
        if (dir.lengthSquared() > 0.0001) {
            dir.normalize().multiply(cfg().getDouble("blue.reflect-knockback", 1.0)).setY(0.25);
            atk.setVelocity(dir);
        }
        p.getWorld().spawnParticle(Particle.CRIT, p.getLocation().add(0, 1.2, 0), 15, 0.3, 0.3, 0.3, 0.2);
        p.getWorld().playSound(p.getLocation(), p.isBlocking() ? Sound.ITEM_SHIELD_BLOCK : Sound.ENTITY_PLAYER_ATTACK_KNOCKBACK, 1f, 1.4f);
        p.sendActionBar(Component.text("Phản Chấn!", NamedTextColor.BLUE));
    }

    /** Lam: giảm sát thương đạn bắn. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlueProjectile(EntityDamageEvent e) {
        if (e.getCause() != DamageCause.PROJECTILE) return;
        if (!(e.getEntity() instanceof Player p) || plugin.getSoul(p) != Soul.BLUE) return;
        double red = Math.max(0, Math.min(0.9, cfg().getDouble("blue.projectile-reduction", 0.25)));
        e.setDamage(e.getDamage() * (1 - red));
    }

    // ===================== Lục - Cứu Rỗi =====================

    /** Ai (kể cả chính Lục) bị đánh xuống dưới ngưỡng máu mà còn sống, gần một người Lục, thì được cứu. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onRescue(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player v) || v.isDead()) return;
        DamageCause c = e.getCause();
        if (c == DamageCause.VOID || c == DamageCause.KILL || c == DamageCause.SUICIDE
                || c == DamageCause.WORLD_BORDER || c == DamageCause.STARVATION) return;
        double max = v.getAttribute(Attribute.MAX_HEALTH).getValue();
        double left = v.getHealth() - e.getFinalDamage();
        if (left <= 0 || left / max > cfg().getDouble("green.rescue-health-ratio", 0.35)) return;
        if (plugin.cdLeftMs(v, "green-rescue") > 0) return;

        double r = cfg().getDouble("green.aura-radius", 10.0);
        Player healer = null;
        for (Player g : Bukkit.getOnlinePlayers()) {
            if (g.isDead() || g.getWorld() != v.getWorld() || plugin.getSoul(g) != Soul.GREEN) continue;
            if (g.getLocation().distanceSquared(v.getLocation()) <= r * r) {
                healer = g;
                break;
            }
        }
        if (healer == null) return;
        plugin.setCd(v, "green-rescue", Math.max(1, cfg().getInt("green.rescue-cooldown-seconds", 40)));

        int regenSecs = cfg().getInt("green.rescue-regen-seconds", 5);
        int regenLvl = cfg().getInt("green.rescue-regen-level", 3);
        int absLvl = cfg().getInt("green.rescue-absorption-level", 2);
        int absSecs = cfg().getInt("green.rescue-absorption-seconds", 10);
        if (regenSecs > 0 && regenLvl > 0) {
            v.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, regenSecs * 20, regenLvl - 1, false, true, true));
        }
        if (absSecs > 0 && absLvl > 0) {
            v.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, absSecs * 20, absLvl - 1, false, true, true));
        }
        v.getWorld().spawnParticle(Particle.HEART, v.getLocation().add(0, 1.5, 0), 12, 0.5, 0.6, 0.5, 0);
        v.getWorld().playSound(v.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.2f);
        v.sendActionBar(Component.text(v.equals(healer) ? "Cứu Rỗi!" : "Được " + healer.getName() + " cứu rỗi!",
                NamedTextColor.GREEN));
    }

    // ===================== Vòng lặp: Lục (hào quang) + dọn dữ liệu =====================

    private void tickAura() {
        double heal = cfg().getDouble("green.aura-heal", 2.0);
        double r = cfg().getDouble("green.aura-radius", 10.0);
        boolean alliesOnly = cfg().getBoolean("green.aura-allies-only", false);
        if (heal <= 0 || r <= 0) return;
        for (Player g : Bukkit.getOnlinePlayers()) {
            if (g.isDead() || plugin.getSoul(g) != Soul.GREEN) continue;
            for (Entity en : g.getNearbyEntities(r, r, r)) {
                if (!(en instanceof Player q) || q.isDead()) continue;
                if (alliesOnly && !Util.isAlly(g, q)) continue;
                double max = q.getAttribute(Attribute.MAX_HEALTH).getValue();
                if (q.getHealth() <= 0 || q.getHealth() >= max) continue;
                q.setHealth(Math.min(max, q.getHealth() + heal));
                q.getWorld().spawnParticle(Particle.HEART, q.getLocation().add(0, 2, 0), 1, 0.2, 0.1, 0.2, 0);
            }
        }
    }

    private void purge() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, Cold>> it = colds.entrySet().iterator();
        while (it.hasNext()) {
            Cold c = it.next().getValue();
            if (now > c.expire && now > c.immuneUntil) it.remove();
        }
        long keep = cfg().getInt("yellow.retaliate-seconds", 8) * 1000L;
        for (Iterator<Map.Entry<UUID, Map<UUID, Long>>> a = yellowFoes.entrySet().iterator(); a.hasNext(); ) {
            Map<UUID, Long> m = a.next().getValue();
            m.values().removeIf(t -> now - t > keep);
            if (m.isEmpty()) a.remove();
        }
    }
}
