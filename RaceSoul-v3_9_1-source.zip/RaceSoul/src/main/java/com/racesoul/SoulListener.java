package com.racesoul;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/** Linh hồn chỉ còn bị động + chỉ số nền (xem Stats). Không còn kỹ năng chủ động. */
public final class SoulListener implements Listener {
    private final SoulPlugin plugin;
    private final NamespacedKey legacyItemKey;

    private static final class Stack {
        int n;
        long expire;
    }

    /** Tím: số tầng Bất Khuất. */
    private final Map<UUID, Stack> stacks = new HashMap<>();
    /** Cyan: thời điểm hết chậm của từng mục tiêu. */
    private final Map<UUID, Long> slowUntil = new HashMap<>();

    public SoulListener(SoulPlugin plugin) {
        this.plugin = plugin;
        this.legacyItemKey = new NamespacedKey(plugin, "soul_item");
        long period = Math.max(1, plugin.getConfig().getInt("green.regen-interval-seconds", 2)) * 20L;
        Bukkit.getScheduler().runTaskTimer(plugin, this::tickGreen, period, period);
        Bukkit.getScheduler().runTaskTimer(plugin, this::tickStacks, 20L, 20L);
    }

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    // ===================== Nhận linh hồn (random khi vào server) =====================

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        cleanLegacyItems(p);
        plugin.refreshStats(p);
        if (!cfg().getBoolean("roll-on-join", true)) return;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline() && plugin.getSoul(p) == null) plugin.rollSoul(p);
        }, 60L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        stacks.remove(e.getPlayer().getUniqueId());
        plugin.saveLoad().clear(e.getPlayer().getUniqueId());
        Stats.clearStacks(plugin, e.getPlayer());
    }

    /** Dọn vật phẩm linh hồn của các bản cũ (2.4 - 2.5), vì giờ không còn kỹ năng chủ động. */
    private void cleanLegacyItems(Player p) {
        PlayerInventory inv = p.getInventory();
        ItemStack[] arr = inv.getContents();
        for (int i = 0; i < arr.length; i++) {
            ItemStack it = arr[i];
            if (it == null || !it.hasItemMeta()) continue;
            if (it.getItemMeta().getPersistentDataContainer().has(legacyItemKey, PersistentDataType.STRING)) {
                inv.setItem(i, null);
            }
        }
    }

    // ===================== Bị động khi NHẬN sát thương =====================

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        Soul s = plugin.getSoul(p);
        if (s == null) return;

        DamageCause c = e.getCause();
        if (c == DamageCause.VOID || c == DamageCause.KILL || c == DamageCause.SUICIDE
                || c == DamageCause.WORLD_BORDER || c == DamageCause.STARVATION) return;

        switch (s) {
            case BLUE -> {
                if (c == DamageCause.FALL) {
                    e.setCancelled(true);
                } else if (c == DamageCause.ENTITY_EXPLOSION || c == DamageCause.BLOCK_EXPLOSION) {
                    double red = Math.max(0, Math.min(0.9, cfg().getDouble("blue.explosion-reduction", 0.30)));
                    e.setDamage(e.getDamage() * (1 - red));
                }
            }
            case HATE -> {
                double red = Math.max(0, Math.min(0.9, cfg().getDouble("hate.damage-reduction", 0.25)));
                e.setDamage(e.getDamage() * (1 - red));
            }
            case PURPLE -> purpleStack(p, e);
            case RED -> redLastStand(p, e);
            case CYAN -> {
                if (e instanceof EntityDamageByEntityEvent be) cyanSlow(p, be);
            }
            default -> { }
        }
    }

    /** Tím: mỗi lần trúng đòn +1 tầng Bất Khuất, mỗi tầng cộng chỉ số (attribute) nên càng bị đánh càng trâu. */
    private void purpleStack(Player p, EntityDamageEvent e) {
        if (e.getFinalDamage() <= 0) return;
        long now = System.currentTimeMillis();
        int max = Math.max(1, cfg().getInt("purple.max-stacks", 5));
        long keep = cfg().getInt("purple.stack-seconds", 10) * 1000L;
        Stack st = stacks.computeIfAbsent(p.getUniqueId(), k -> new Stack());
        if (now > st.expire) st.n = 0;
        st.n = Math.min(max, st.n + 1);
        st.expire = now + keep;
        Stats.applyStacks(plugin, p, st.n);
        p.sendActionBar(Component.text("Bất Khuất x" + st.n, NamedTextColor.DARK_PURPLE));
        p.getWorld().spawnParticle(Particle.DUST, p.getLocation().add(0, 1, 0), 8, 0.4, 0.6, 0.4, 0,
                new Particle.DustOptions(Color.PURPLE, 1.2f));
    }

    /** Hết hạn tầng / đổi linh hồn / thoát game thì gỡ chỉ số của tầng. */
    private void tickStacks() {
        if (stacks.isEmpty()) return;
        long now = System.currentTimeMillis();
        java.util.Iterator<Map.Entry<UUID, Stack>> it = stacks.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Stack> en = it.next();
            Player p = Bukkit.getPlayer(en.getKey());
            if (p == null) {
                it.remove();
            } else if (now > en.getValue().expire || plugin.getSoul(p) != Soul.PURPLE) {
                Stats.clearStacks(plugin, p);
                it.remove();
            }
        }
    }

    /** Đỏ: sau một đòn mà máu còn dưới ngưỡng (nhưng chưa chết) thì nhận chỉ số tạm thời + hồi máu mỗi giây. */
    private void redLastStand(Player p, EntityDamageEvent e) {
        double dmg = e.getFinalDamage();
        if (dmg <= 0) return;
        double max = p.getAttribute(Attribute.MAX_HEALTH).getValue();
        double left = p.getHealth() - dmg;
        if (left <= 0) {
            // Không Chịu Gục: đòn chí mạng thì sống sót với ít máu (hồi chiêu dài) và kích hoạt Quyết Tâm ngay
            int surviveCd = cfg().getInt("red.survive-cooldown-seconds", 300);
            if (surviveCd <= 0 || plugin.cdLeftMs(p, "red-survive") > 0) return;
            plugin.setCd(p, "red-survive", surviveCd);
            e.setCancelled(true);
            p.setHealth(Math.max(1.0, Math.min(max, cfg().getDouble("red.survive-health", 2.0))));
            p.setNoDamageTicks(20);
            p.getWorld().playSound(p.getLocation(), Sound.ITEM_TOTEM_USE, 1f, 1f);
            p.sendActionBar(Component.text("KHÔNG CHỊU GỤC!", NamedTextColor.RED));
            plugin.setCd(p, "red-laststand", cfg().getInt("red.cooldown-seconds", 180));
            startLastStandBuff(p);
            return;
        }
        if (left / max > cfg().getDouble("red.health-ratio", 0.30)) return;
        if (plugin.cdLeftMs(p, "red-laststand") > 0) return;
        plugin.setCd(p, "red-laststand", cfg().getInt("red.cooldown-seconds", 180));
        startLastStandBuff(p);
    }

    /** Quyết Tâm: chỉ số tạm thời + hồi máu mỗi giây trong buff-seconds. */
    private void startLastStandBuff(Player p) {
        int seconds = Math.max(1, cfg().getInt("red.buff-seconds", 6));
        Stats.applyTemp(plugin, p, cfg().getConfigurationSection("red.buff"), "buf_");
        Bukkit.getScheduler().runTaskLater(plugin, () -> Stats.removeTemp(plugin, p, "buf_"), seconds * 20L);

        final double healPerSec = cfg().getDouble("red.heal-per-second", 1.0);
        if (healPerSec > 0) {
            new BukkitRunnable() {
                int remaining = seconds;

                @Override
                public void run() {
                    if (!p.isOnline() || p.isDead() || remaining-- <= 0) {
                        cancel();
                        return;
                    }
                    double mx = p.getAttribute(Attribute.MAX_HEALTH).getValue();
                    p.setHealth(Math.min(mx, p.getHealth() + healPerSec));
                }
            }.runTaskTimer(plugin, 20L, 20L);
        }

        p.getWorld().spawnParticle(Particle.DUST, p.getLocation().add(0, 1, 0), 25, 0.4, 0.8, 0.4, 0,
                new Particle.DustOptions(Color.RED, 1.4f));
        p.getWorld().playSound(p.getLocation(), Sound.ITEM_TOTEM_USE, 0.6f, 1.4f);
        p.sendActionBar(Component.text("Quyết Tâm!", NamedTextColor.RED));
    }

    /** Cyan: bị đánh cận chiến thì có xác suất làm kẻ tấn công chậm lại (giảm tốc độ chạy bằng attribute). */
    private void cyanSlow(Player p, EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof LivingEntity atk) || !Util.canTarget(p, atk)) return;
        if (ThreadLocalRandom.current().nextDouble() >= cfg().getDouble("cyan.slow-chance", 0.35)) return;
        int seconds = Math.max(1, cfg().getInt("cyan.slow-seconds", 3));
        long ticks = seconds * 20L;
        UUID id = atk.getUniqueId();
        slowUntil.put(id, System.currentTimeMillis() + seconds * 1000L);
        Stats.applyTemp(plugin, atk, cfg().getConfigurationSection("cyan.slow"), "slw_");
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Long until = slowUntil.get(id);
            if (until == null || System.currentTimeMillis() >= until - 200L) {
                Stats.removeTemp(plugin, atk, "slw_");
                slowUntil.remove(id);
            }
        }, ticks + 2L);
    }

    // ===================== Bị động khi GÂY sát thương =====================

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDealDamage(EntityDamageByEntityEvent e) {
        Player p;
        boolean ranged = false;
        if (e.getDamager() instanceof Player direct) {
            p = direct;
        } else if (e.getDamager() instanceof Projectile pr && pr.getShooter() instanceof Player shooter) {
            p = shooter;
            ranged = true;
        } else {
            return;
        }
        Soul s = plugin.getSoul(p);
        if (s != Soul.ORANGE && s != Soul.YELLOW) return;
        if (!(e.getEntity() instanceof LivingEntity victim) || !Util.canTarget(p, victim)) return;

        double bonus = 0;
        if (s == Soul.ORANGE && !ranged) bonus = cfg().getDouble("orange.damage-bonus", 0.10);
        else if (s == Soul.YELLOW && ranged) bonus = cfg().getDouble("yellow.projectile-bonus", 0.15);
        if (bonus > 0) e.setDamage(e.getDamage() * (1 + bonus));
    }

    /** Đen: đánh thường hút máu. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHateMelee(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (plugin.getSoul(p) != Soul.HATE) return;
        if (!(e.getEntity() instanceof LivingEntity le) || !Util.canTarget(p, le)) return;
        double heal = e.getFinalDamage() * cfg().getDouble("hate.melee-lifesteal", 0.2);
        if (heal <= 0) return;
        double max = p.getAttribute(Attribute.MAX_HEALTH).getValue();
        p.setHealth(Math.min(max, p.getHealth() + heal));
    }

    // ===================== Xanh lá: hồi máu chậm liên tục =====================

    private void tickGreen() {
        double amount = cfg().getDouble("green.regen-amount", 1.0);
        if (amount <= 0) return;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.isDead() || plugin.getSoul(p) != Soul.GREEN) continue;
            double max = p.getAttribute(Attribute.MAX_HEALTH).getValue();
            double hp = p.getHealth();
            if (hp <= 0 || hp >= max) continue;
            p.setHealth(Math.min(max, hp + amount));
        }
    }
}
