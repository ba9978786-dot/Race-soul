package com.racesoul;

import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.List;

public enum Soul {
    RED("red", "Quyết Tâm", NamedTextColor.RED, Material.RED_DYE),
    ORANGE("orange", "Dũng Cảm", NamedTextColor.GOLD, Material.ORANGE_DYE),
    YELLOW("yellow", "Công Lý", NamedTextColor.YELLOW, Material.YELLOW_DYE),
    GREEN("green", "Tử Tế", NamedTextColor.GREEN, Material.LIME_DYE),
    BLUE("blue", "Chính Trực", NamedTextColor.BLUE, Material.BLUE_DYE),
    CYAN("cyan", "Kiên Nhẫn", NamedTextColor.AQUA, Material.CYAN_DYE),
    PURPLE("purple", "Kiên Trì", NamedTextColor.DARK_PURPLE, Material.PURPLE_DYE),
    /** Linh hồn ẩn: không bao giờ random trúng, phải được mở khoá mới dùng được. */
    HATE("hate", "Căm Hận", NamedTextColor.DARK_GRAY, Material.BLACK_DYE, true);

    public final String id;
    public final String title;
    public final NamedTextColor color;
    public final Material icon;
    /** true = linh hồn ẩn (không nằm trong random, cần mở khoá). */
    public final boolean hidden;

    Soul(String id, String title, NamedTextColor color, Material icon) {
        this(id, title, color, icon, false);
    }

    Soul(String id, String title, NamedTextColor color, Material icon, boolean hidden) {
        this.id = id;
        this.title = title;
        this.color = color;
        this.icon = icon;
        this.hidden = hidden;
    }

    /** Random 1 linh hồn thường (không bao giờ ra linh hồn ẩn). */
    public static Soul random() {
        List<Soul> pool = new java.util.ArrayList<>();
        for (Soul s : values()) if (!s.hidden) pool.add(s);
        return pool.get(java.util.concurrent.ThreadLocalRandom.current().nextInt(pool.size()));
    }

    public static Soul byId(String id) {
        for (Soul s : values()) if (s.id.equals(id)) return s;
        return null;
    }

    /** Mô tả kỹ năng + chỉ số nền, lấy số liệu từ config. */
    public List<String> describe(FileConfiguration c) {
        List<String> out = new java.util.ArrayList<>(skillLines(c));
        out.addAll(Stats.describe(c, this));
        return out;
    }

    private List<String> skillLines(FileConfiguration c) {
        switch (this) {
            case RED:
                return List.of(
                        "Quyết Tâm (bị động): sau một đòn khiến máu còn dưới "
                                + (int) (c.getDouble("red.health-ratio", 0.30) * 100) + "% (mà chưa chết), trong "
                                + c.getInt("red.buff-seconds", 6) + "s nhận: "
                                + String.join(", ", Stats.describeAt(c, "red.buff")) + ",",
                        "và hồi " + c.getDouble("red.heal-per-second", 1.0) + " máu mỗi giây. Hồi "
                                + c.getInt("red.cooldown-seconds", 180) + " giây.",
                        "Không Chịu Gục: dính đòn chí mạng thì sống sót với " + c.getDouble("red.survive-health", 2.0)
                                + " máu và kích hoạt Quyết Tâm ngay (hồi " + c.getInt("red.survive-cooldown-seconds", 300) + " giây).",
                        "Kỹ năng SAVE/LOAD (dùng Ngôi sao SAVE trong túi): chuột phải = SAVE vị trí + máu + thức ăn"
                                + " (hết hạn sau " + c.getInt("red.save-load.save-expire-seconds", 300) + "s),",
                        "chuột phải lần nữa = LOAD quay về điểm đó và hồi máu lên mức đã lưu. Hồi load "
                                + c.getInt("red.save-load.load-cooldown-seconds", 90) + " giây.",
                        "Shift + chuột phải = SAVE lại điểm mới. Mất sao: /linhhon item (hoặc /linhhon save, /linhhon load).");
            case ORANGE:
                return List.of(
                        "Dũng Cảm (bị động): +" + (int) (c.getDouble("orange.damage-bonus", 0.10) * 100)
                                + "% sát thương cận chiến.",
                        "Xung Phong: đánh khi đang chạy nhanh gây thêm +" + c.getDouble("orange.charge-damage", 5.0)
                                + " sát thương và hất kẻ địch ra xa (hồi " + c.getInt("orange.charge-cooldown-seconds", 5) + "s).",
                        "Khải Hoàn: hạ gục sinh vật thì hồi " + c.getDouble("orange.kill-heal", 4.0)
                                + " máu và Speed " + c.getInt("orange.kill-speed-level", 2) + " trong "
                                + c.getInt("orange.kill-speed-seconds", 4) + "s.");
            case YELLOW:
                return List.of(
                        "Công Lý (bị động): +" + (int) (c.getDouble("yellow.projectile-bonus", 0.15) * 100)
                                + "% sát thương đạn bắn (cung, nỏ, đinh ba...).",
                        "Phán Quyết: đạn bắn trúng gây thêm +" + c.getDouble("yellow.verdict-damage", 8.0)
                                + " sát thương và làm mục tiêu phát sáng " + c.getInt("yellow.verdict-glow-seconds", 5)
                                + "s (hồi " + c.getInt("yellow.verdict-cooldown-seconds", 4) + "s).",
                        "Đền Tội: đánh kẻ vừa đánh bạn (trong " + c.getInt("yellow.retaliate-seconds", 8)
                                + "s) thì +" + (int) (c.getDouble("yellow.retaliate-bonus", 0.30) * 100) + "% sát thương.");
            case GREEN:
                return List.of(
                        "Tử Tế (bị động): tự hồi " + c.getDouble("green.regen-amount", 1.0) + " máu mỗi "
                                + c.getInt("green.regen-interval-seconds", 2) + " giây khi chưa đầy máu.",
                        "Hào Quang: người chơi trong " + c.getDouble("green.aura-radius", 10.0)
                                + " block quanh bạn được hồi " + c.getDouble("green.aura-heal", 2.0)
                                + " máu mỗi " + c.getInt("green.aura-interval-seconds", 2) + " giây.",
                        "Cứu Rỗi: ai (kể cả bạn) gần bạn bị đánh xuống dưới "
                                + (int) (c.getDouble("green.rescue-health-ratio", 0.35) * 100)
                                + "% máu thì nhận Hồi Phục + Máu Ảo (mỗi người hồi "
                                + c.getInt("green.rescue-cooldown-seconds", 40) + "s).");
            case BLUE:
                return List.of(
                        "Chính Trực (bị động): miễn sát thương rơi, giảm "
                                + (int) (c.getDouble("blue.explosion-reduction", 0.30) * 100) + "% sát thương nổ và "
                                + (int) (c.getDouble("blue.projectile-reduction", 0.25) * 100) + "% sát thương đạn bắn.",
                        "Phản Chấn: bị đánh cận chiến thì phản lại "
                                + (int) (c.getDouble("blue.reflect-ratio", 0.35) * 100) + "% sát thương ("
                                + (int) (c.getDouble("blue.reflect-block-ratio", 0.75) * 100)
                                + "% nếu đang giơ khiên) và đẩy kẻ tấn công ra.");
            case CYAN:
                return List.of(
                        "Kiên Nhẫn (bị động): khi bị đánh cận chiến, "
                                + (int) (c.getDouble("cyan.slow-chance", 0.35) * 100) + "% làm kẻ tấn công",
                        "bị " + String.join(", ", Stats.describeAt(c, "cyan.slow")) + " trong "
                                + c.getInt("cyan.slow-seconds", 3) + "s.",
                        "Sương Giá: mỗi đòn cận chiến +1 tầng lạnh lên mục tiêu (càng nhiều càng chậm); đủ "
                                + c.getInt("cyan.frost-hits", 4) + " tầng thì ĐÓNG BĂNG "
                                + c.getInt("cyan.frost-freeze-seconds", 2) + "s.",
                        "Kẻ đang bị lạnh đánh bạn chỉ gây "
                                + (100 - (int) (c.getDouble("cyan.frost-damage-reduction", 0.30) * 100)) + "% sát thương.");
            case PURPLE: {
                List<String> l = new java.util.ArrayList<>();
                l.add("Bất Khuất (bị động): mỗi lần trúng đòn +1 tầng (tối đa "
                        + c.getInt("purple.max-stacks", 5) + "), hết sau "
                        + c.getInt("purple.stack-seconds", 10) + "s không bị đánh.");
                for (String s : Stats.describePerStack(c)) l.add("Mỗi tầng: " + s);
                return l;
            }
            case HATE:
                return List.of(
                        "Căm Hận (linh hồn ẩn, bị động): giảm "
                                + (int) (c.getDouble("hate.damage-reduction", 0.25) * 100) + "% sát thương nhận,",
                        "đánh thường hút " + (int) (c.getDouble("hate.melee-lifesteal", 0.2) * 100) + "% máu.",
                        "Lời Nguyền: mỗi đòn đánh thường làm mục tiêu bị Héo Mòn " + c.getInt("hate.wither-level", 2)
                                + " trong " + c.getInt("hate.wither-seconds", 4) + "s.",
                        "Nuốt Chửng: hạ gục sinh vật thì hồi " + c.getDouble("hate.kill-heal", 6.0)
                                + " máu và nhận Máu Ảo " + c.getInt("hate.kill-absorption-level", 1) + ".",
                        "Dùng /linhhon hate để chuyển qua lại với linh hồn gốc.");
            default:
                return List.of();
        }
    }
}
