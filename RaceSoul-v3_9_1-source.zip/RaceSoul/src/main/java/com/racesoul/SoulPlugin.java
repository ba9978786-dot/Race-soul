package com.racesoul;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

public final class SoulPlugin extends JavaPlugin {

    private NamespacedKey soulKey;
    private NamespacedKey baseKey;
    private NamespacedKey hateUnlockKey;
    private final Map<String, Long> cooldowns = new HashMap<>();
    private RaceBridge races;
    private SaveLoad saveLoad;
    private final Set<java.util.UUID> rolling = new HashSet<>();
    private final Map<java.util.UUID, String> lastRace = new HashMap<>();

    public RaceBridge races() {
        return races;
    }

    public SaveLoad saveLoad() {
        return saveLoad;
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        soulKey = new NamespacedKey(this, "soul");
        baseKey = new NamespacedKey(this, "base_soul");
        hateUnlockKey = new NamespacedKey(this, "hate_unlocked");
        races = new RaceBridge(this);
        saveLoad = new SaveLoad(this);
        Bukkit.getPluginManager().registerEvents(new SoulListener(this), this);
        Bukkit.getPluginManager().registerEvents(new SoulSkills(this), this);
        Bukkit.getPluginManager().registerEvents(new SaveItemListener(this), this);
        long period = Math.max(1, getConfig().getInt("synergy.check-seconds", 2)) * 20L;
        // Kiểm tra định kỳ (mặc định 2 giây): đổi tộc (RaceFantasy) thì tính lại cộng hưởng
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player pl : Bukkit.getOnlinePlayers()) {
                String r = races.raceOf(pl);
                String old = lastRace.put(pl.getUniqueId(), r == null ? "" : r);
                if (old == null || !old.equals(r == null ? "" : r)) Stats.apply(this, pl, getSoul(pl));
            }
        }, period, period);
        SoulCommand cmd = new SoulCommand(this);
        getCommand("linhhon").setExecutor(cmd);
        getCommand("linhhon").setTabCompleter(cmd);
        for (Player p : Bukkit.getOnlinePlayers()) {
            Stats.apply(this, p, getSoul(p));
            saveLoad.syncItem(p);
        }
        getLogger().info("RaceSoul đã bật.");
    }

    @Override
    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) Stats.clear(this, p);
    }

    /** Gắn lại chỉ số nền theo linh hồn hiện tại. */
    public void refreshStats(Player p) {
        Stats.apply(this, p, getSoul(p));
        saveLoad.syncItem(p); // Đỏ có Ngôi sao SAVE, linh hồn khác thì thu hồi
    }

    // ---------- Linh hồn (lưu trong dữ liệu người chơi, giữ qua restart) ----------

    public Soul getSoul(Player p) {
        String id = p.getPersistentDataContainer().get(soulKey, PersistentDataType.STRING);
        return id == null ? null : Soul.byId(id);
    }

    /** Đang chạy hiệu ứng quay linh hồn (chưa công bố kết quả). */
    public boolean isRolling(Player p) {
        return rolling.contains(p.getUniqueId());
    }

    /**
     * Random 1 linh hồn thường cho người chơi chưa có linh hồn. Trả về null nếu đã có rồi.
     * Kết quả được chốt (lưu) ngay, còn hiệu ứng chữ nhảy liên tục chỉ để công bố cho kịch tính.
     */
    public Soul rollSoul(Player p) {
        if (getSoul(p) != null) return null;
        Soul result = Soul.random();
        p.getPersistentDataContainer().set(soulKey, PersistentDataType.STRING, result.id);
        if (getConfig().getBoolean("roll-animation", true)) {
            rolling.add(p.getUniqueId());
            List<Soul> pool = new ArrayList<>();
            for (Soul x : Soul.values()) if (!x.hidden) pool.add(x);
            int frames = 20;
            List<Soul> seq = new ArrayList<>();
            Soul prev = null;
            for (int i = 0; i < frames - 1; i++) {
                Soul pick;
                do {
                    pick = pool.get(ThreadLocalRandom.current().nextInt(pool.size()));
                } while (pick == prev || (i == frames - 2 && pick == result));
                seq.add(pick);
                prev = pick;
            }
            seq.add(result);
            rollStep(p, seq, 0);
        } else {
            finishRoll(p, result);
        }
        return result;
    }

    /** Một khung của hiệu ứng: đổi chữ liên tục, càng về cuối càng chậm, khung cuối là kết quả thật. */
    private void rollStep(Player p, List<Soul> seq, int i) {
        if (!p.isOnline()) {
            rolling.remove(p.getUniqueId());
            return; // linh hồn đã được chốt, vào lại server sẽ nhận chỉ số
        }
        Soul s = seq.get(i);
        if (i == seq.size() - 1) {
            finishRoll(p, s);
            return;
        }
        p.showTitle(Title.title(
                Component.text(s.title, s.color).decorate(TextDecoration.BOLD),
                Component.text("Đang xác định linh hồn...", NamedTextColor.GRAY),
                Title.Times.times(Duration.ZERO, Duration.ofMillis(1500), Duration.ZERO)));
        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.8f, 0.8f + 0.9f * i / seq.size());
        double t = i / (double) (seq.size() - 1);
        long delay = 2L + Math.round(Math.pow(t, 2.2) * 14.0); // 2 tick lúc đầu -> khoảng 16 tick lúc cuối
        Bukkit.getScheduler().runTaskLater(this, () -> rollStep(p, seq, i + 1), delay);
    }

    /** Công bố kết quả: gắn chỉ số, vật phẩm, hiệu ứng. */
    private void finishRoll(Player p, Soul s) {
        rolling.remove(p.getUniqueId());
        refreshStats(p);
        p.showTitle(Title.title(
                Component.text(s.title, s.color).decorate(TextDecoration.BOLD),
                Component.text("Linh hồn của bạn", NamedTextColor.GRAY),
                Title.Times.times(Duration.ZERO, Duration.ofMillis(3000), Duration.ofMillis(1000))));
        p.sendMessage(Component.text("Linh hồn của bạn là: Linh hồn " + s.title + "!", s.color));
        p.sendMessage(Component.text("Gõ /linhhon để xem bị động và chỉ số.", NamedTextColor.GRAY));
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);
        p.playSound(p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.7f, 1.4f);
        p.getWorld().spawnParticle(Particle.HEART, p.getLocation().add(0, 1.5, 0), 8, 0.4, 0.4, 0.4, 0);
    }

    /** Chỉ dùng cho lệnh admin khẩn cấp: xóa linh hồn (kể cả bản gốc đang lưu khi dùng Hate). */
    public void resetSoul(Player p) {
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        pdc.remove(soulKey);
        pdc.remove(baseKey);
        Stats.clear(this, p);
    }

    // ---------- Linh hồn ẩn: Căm Hận ----------

    public boolean isHateUnlocked(Player p) {
        return p.getPersistentDataContainer().has(hateUnlockKey, PersistentDataType.BYTE);
    }

    public void setHateUnlocked(Player p, boolean unlocked) {
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        if (unlocked) {
            pdc.set(hateUnlockKey, PersistentDataType.BYTE, (byte) 1);
        } else {
            pdc.remove(hateUnlockKey);
            // Khoá lại: nếu đang dùng Hate thì trả về linh hồn gốc
            if (getSoul(p) == Soul.HATE) restoreBase(p);
        }
    }

    /** Chuyển qua lại giữa Căm Hận và linh hồn gốc. Trả về linh hồn hiện tại sau khi chuyển. */
    public Soul toggleHate(Player p) {
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        Soul cur = getSoul(p);
        if (cur == Soul.HATE) {
            restoreBase(p);
        } else {
            if (cur != null) pdc.set(baseKey, PersistentDataType.STRING, cur.id);
            pdc.set(soulKey, PersistentDataType.STRING, Soul.HATE.id);
        }
        refreshStats(p);
        return getSoul(p);
    }

    private void restoreBase(Player p) {
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        String id = pdc.get(baseKey, PersistentDataType.STRING);
        Soul base = id == null ? null : Soul.byId(id);
        if (base == null || base.hidden) base = Soul.random();
        pdc.set(soulKey, PersistentDataType.STRING, base.id);
        pdc.remove(baseKey);
        refreshStats(p);
    }

    // ---------- Hồi chiêu ----------

    public long cdLeftMs(Player p, String key) {
        Long t = cooldowns.get(p.getUniqueId() + ":" + key);
        if (t == null) return 0;
        return Math.max(0, t - System.currentTimeMillis());
    }

    public void setCd(Player p, String key, long seconds) {
        cooldowns.put(p.getUniqueId() + ":" + key, System.currentTimeMillis() + seconds * 1000L);
    }

    /** Nếu đang hồi chiêu thì báo trên action bar và trả về true. */
    public boolean onCooldown(Player p, String key) {
        long left = cdLeftMs(p, key);
        if (left > 0) {
            p.sendActionBar(Component.text(
                    "Hồi chiêu: " + Util.secondsLeft(left) + " giây",
                    NamedTextColor.GRAY));
            return true;
        }
        return false;
    }
}
