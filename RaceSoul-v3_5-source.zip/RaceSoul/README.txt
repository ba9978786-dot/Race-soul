RaceSoul v3.0 - 7 linh hồn kiểu Glitchtale (add-on cho RaceFantasy)

Build:   mvn clean package        -> target/RaceSoul.jar
Cài:     bỏ RaceSoul.jar vào plugins/ (chạy cùng RaceFantasy), restart server
Lệnh:    /linhhon  (alias /soul, /hl)  - xem linh hồn của mình (chưa có thì random)
         /linhhon hate                 - chuyển qua lại Căm Hận <-> linh hồn gốc (cần mở khoá)
         /linhhon reset <tên>          - admin: xoá và random lại linh hồn
         /linhhon unlock <tên>         - admin: mở khoá linh hồn ẩn Căm Hận (đen)
         /linhhon lock <tên>           - admin: khoá lại
Linh hồn random khi vào server (không tự chọn, không đổi). Căm Hận không bao giờ random trúng.
Số liệu chỉnh trong plugins/RaceSoul/config.yml
Từ v3.0: không còn kỹ năng chủ động. Mỗi linh hồn có 1 bị động + chỉ số nền (mục stats) + cộng hưởng với tộc RaceFantasy (mục synergy).

v3.3: Linh hồn Đỏ (Quyết Tâm) có kỹ năng SAVE/LOAD:
         /linhhon save   - lưu vị trí + máu + thức ăn (hiện ngôi sao tại điểm lưu)
         /linhhon load   - quay lại điểm đã lưu, hồi máu lên mức đã lưu
       Chỉnh trong config.yml mục red.save-load.

v3.4: Đỏ tự nhận Ngôi sao SAVE (nether star, không rơi/không cất rương, giữ khi chết).
         Chuột phải = SAVE; chuột phải lần nữa = LOAD; Shift+chuột phải = SAVE lại.
         /linhhon item - nhận lại sao nếu mất. Tắt phát item: red.save-load.give-item: false

v3.5: Hiệu ứng quay linh hồn: tên các linh hồn nhảy liên tục trên màn hình, chậm dần rồi dừng ở linh hồn nhận được.
       Tắt bằng roll-animation: false trong config.yml.
