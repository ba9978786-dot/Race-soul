package com.racesoul;

import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlotGroup;

import java.util.ArrayList;
import java.util.List;

/** Chỉ số nền (buff thường trực) theo linh hồn, cấu hình trong config.yml mục "stats". */
public final class Stats {
    private Stats() {}

    private record Def(String key, String label, Attribute attr, AttributeModifier.Operation op, boolean percent) {}

    private static final List<Def> DEFS = List.of(
            new Def("max-health", "máu tối đa (nửa tim)", Attribute.MAX_HEALTH, AttributeModifier.Operation.ADD_NUMBER, false),
            new Def("attack-damage", "sát thương cận chiến", Attribute.ATTACK_DAMAGE, AttributeModifier.Operation.ADD_NUMBER, false),
            new Def("attack-speed", "tốc độ đánh", Attribute.ATTACK_SPEED, AttributeModifier.Operation.ADD_SCALAR, true),
            new Def("movement-speed", "tốc độ chạy", Attribute.MOVEMENT_SPEED, AttributeModifier.Operation.ADD_SCALAR, true),
            new Def("armor", "giáp", Attribute.ARMOR, AttributeModifier.Operation.ADD_NUMBER, false),
            new Def("knockback-resistance", "kháng đẩy lùi", Attribute.KNOCKBACK_RESISTANCE, AttributeModifier.Operation.ADD_NUMBER, true),
            new Def("interaction-range", "tầm đánh", Attribute.ENTITY_INTERACTION_RANGE, AttributeModifier.Operation.ADD_NUMBER, false)
    );

    private static NamespacedKey nk(SoulPlugin plugin, Def d, String prefix) {
        return new NamespacedKey(plugin, prefix + d.key());
    }

    private static void remove(SoulPlugin plugin, LivingEntity p, String... prefixes) {
        for (Def d : DEFS) {
            AttributeInstance inst = p.getAttribute(d.attr());
            if (inst == null) continue;
            for (AttributeModifier m : new ArrayList<>(inst.getModifiers())) {
                for (String pre : prefixes) {
                    if (nk(plugin, d, pre).equals(m.getKey())) {
                        inst.removeModifier(m);
                        break;
                    }
                }
            }
        }
    }

    /** Gỡ mọi chỉ số RaceSoul đang gắn trên người chơi (nền, cộng hưởng, tầng Bất Khuất). */
    public static void clear(SoulPlugin plugin, Player p) {
        remove(plugin, p, "stat_", "syn_", "stk_", "buf_", "slw_");
    }

    /** Gỡ riêng chỉ số do tầng Bất Khuất (Tím) tạo ra. */
    public static void clearStacks(SoulPlugin plugin, Player p) {
        remove(plugin, p, "stk_");
    }

    /** Tím: gắn chỉ số theo số tầng Bất Khuất (cấu hình purple.per-stack, nhân với số tầng). */
    public static void applyStacks(SoulPlugin plugin, Player p, int n) {
        clearStacks(plugin, p);
        if (n <= 0) return;
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("purple.per-stack");
        if (sec == null) return;
        for (Def d : DEFS) {
            double v = sec.getDouble(d.key(), 0.0) * n;
            if (v == 0.0) continue;
            AttributeInstance inst = p.getAttribute(d.attr());
            if (inst == null) continue;
            inst.addModifier(new AttributeModifier(nk(plugin, d, "stk_"), v, d.op(), EquipmentSlotGroup.ANY));
        }
    }

    /** Gắn chỉ số TẠM THỜI (transient, không lưu khi thoát game) từ một mục config lên bất kỳ sinh vật nào. */
    public static void applyTemp(SoulPlugin plugin, LivingEntity e, ConfigurationSection sec, String prefix) {
        remove(plugin, e, prefix);
        if (sec == null) return;
        for (Def d : DEFS) {
            double v = sec.getDouble(d.key(), 0.0);
            if (v == 0.0) continue;
            AttributeInstance inst = e.getAttribute(d.attr());
            if (inst == null) continue;
            inst.addTransientModifier(new AttributeModifier(nk(plugin, d, prefix), v, d.op(), EquipmentSlotGroup.ANY));
        }
    }

    /** Gỡ chỉ số tạm thời đã gắn bằng applyTemp. */
    public static void removeTemp(SoulPlugin plugin, LivingEntity e, String prefix) {
        remove(plugin, e, prefix);
    }

    /** Mô tả các chỉ số trong một mục config (vd "purple.per-stack"). */
    public static List<String> describeAt(FileConfiguration c, String path) {
        List<String> out = new ArrayList<>();
        ConfigurationSection sec = c.getConfigurationSection(path);
        if (sec == null) return out;
        for (Def d : DEFS) {
            double v = sec.getDouble(d.key(), 0.0);
            if (v != 0.0) out.add(fmt(d, v) + " " + d.label());
        }
        return out;
    }

    /** Mô tả chỉ số mỗi tầng Bất Khuất. */
    public static List<String> describePerStack(FileConfiguration c) {
        return describeAt(c, "purple.per-stack");
    }

    /** Gỡ chỉ số cũ rồi gắn chỉ số theo linh hồn hiện tại (s = null thì chỉ gỡ). */
    public static void apply(SoulPlugin plugin, Player p, Soul s) {
        remove(plugin, p, "stat_", "syn_");
        FileConfiguration c = plugin.getConfig();
        if (s != null && c.getBoolean("stats.enabled", true)) {
            addSection(plugin, p, c.getConfigurationSection("stats." + s.id), "stat_");
            String race = plugin.races().raceOf(p);
            if (race != null && c.getBoolean("synergy.enabled", true)) {
                addSection(plugin, p, c.getConfigurationSection("synergy." + race + "." + s.id), "syn_");
            }
        }
        // Máu tối đa giảm thì không để máu hiện tại vượt quá
        AttributeInstance hp = p.getAttribute(Attribute.MAX_HEALTH);
        if (hp != null && p.getHealth() > hp.getValue()) p.setHealth(hp.getValue());
    }

    private static void addSection(SoulPlugin plugin, Player p, ConfigurationSection sec, String prefix) {
        if (sec == null) return;
        for (Def d : DEFS) {
            double v = sec.getDouble(d.key(), 0.0);
            if (v == 0.0) continue;
            AttributeInstance inst = p.getAttribute(d.attr());
            if (inst == null) continue;
            inst.addModifier(new AttributeModifier(nk(plugin, d, prefix), v, d.op(), EquipmentSlotGroup.ANY));
        }
    }

    private static String fmt(Def d, double v) {
        return d.percent() ? (v > 0 ? "+" : "") + Math.round(v * 100) + "%"
                           : (v > 0 ? "+" : "") + (v == Math.rint(v) ? String.valueOf((long) v) : String.valueOf(v));
    }

    /** Mô tả cộng hưởng tộc × linh hồn của người chơi (rỗng nếu không có). */
    public static List<String> describeSynergy(SoulPlugin plugin, Player p, Soul s) {
        List<String> out = new ArrayList<>();
        FileConfiguration c = plugin.getConfig();
        if (s == null || !c.getBoolean("stats.enabled", true) || !c.getBoolean("synergy.enabled", true)) return out;
        String race = plugin.races().raceOf(p);
        if (race == null) return out;
        ConfigurationSection sec = c.getConfigurationSection("synergy." + race + "." + s.id);
        if (sec == null) return out;
        for (Def d : DEFS) {
            double v = sec.getDouble(d.key(), 0.0);
            if (v != 0.0) out.add("Cộng hưởng tộc " + race + " × " + s.title + ": " + fmt(d, v) + " " + d.label());
        }
        return out;
    }

    /** Dòng mô tả chỉ số nền của một linh hồn (dùng cho /linhhon). */
    public static List<String> describe(FileConfiguration c, Soul s) {
        List<String> out = new ArrayList<>();
        if (!c.getBoolean("stats.enabled", true)) return out;
        ConfigurationSection sec = c.getConfigurationSection("stats." + s.id);
        if (sec == null) return out;
        for (Def d : DEFS) {
            double v = sec.getDouble(d.key(), 0.0);
            if (v == 0.0) continue;
            String num = d.percent() ? (v > 0 ? "+" : "") + Math.round(v * 100) + "%"
                                      : (v > 0 ? "+" : "") + (v == Math.rint(v) ? String.valueOf((long) v) : String.valueOf(v));
            out.add("Chỉ số nền: " + num + " " + d.label());
        }
        return out;
    }
}
