package com.racesoul;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;

/** Đọc tộc của người chơi từ RaceFantasy bằng reflection (không cần RaceFantasy để biên dịch). */
public final class RaceBridge {
    private final SoulPlugin plugin;
    private Method racesM;
    private Method raceOfM;
    private boolean warned;

    public RaceBridge(SoulPlugin plugin) {
        this.plugin = plugin;
    }

    /** Id tộc (vd "draconian", "human"...) hoặc null nếu không có RaceFantasy / chưa chọn tộc. */
    public String raceOf(Player p) {
        try {
            Plugin rf = Bukkit.getPluginManager().getPlugin("RaceFantasy");
            if (rf == null || !rf.isEnabled()) return null;
            if (racesM == null) racesM = rf.getClass().getMethod("races");
            Object rm = racesM.invoke(rf);
            if (rm == null) return null;
            if (raceOfM == null) raceOfM = rm.getClass().getMethod("raceOf", Player.class);
            Object r = raceOfM.invoke(rm, p);
            return r == null ? null : r.toString();
        } catch (Exception ex) {
            racesM = null;
            raceOfM = null;
            if (!warned) {
                warned = true;
                plugin.getLogger().warning("Không đọc được tộc từ RaceFantasy: " + ex);
            }
            return null;
        }
    }
}
