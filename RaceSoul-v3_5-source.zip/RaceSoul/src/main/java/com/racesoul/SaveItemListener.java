package com.racesoul;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Ngôi sao SAVE của Đỏ: chuột phải để SAVE, chuột phải lần nữa để LOAD. */
public final class SaveItemListener implements Listener {
    private final SoulPlugin plugin;
    private final SaveLoad sl;
    private final Map<UUID, Long> lastUse = new HashMap<>();

    public SaveItemListener(SoulPlugin plugin) {
        this.plugin = plugin;
        this.sl = plugin.saveLoad();
    }

    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;
        if (!sl.isItem(e.getItem())) return;
        e.setCancelled(true);

        Player p = e.getPlayer();
        if (plugin.getSoul(p) != Soul.RED) {
            sl.syncItem(p); // không còn là Đỏ: thu hồi vật phẩm
            return;
        }
        long now = System.currentTimeMillis();
        Long last = lastUse.get(p.getUniqueId());
        if (last != null && now - last < 300L) return; // chống bấm đúp
        lastUse.put(p.getUniqueId(), now);

        if (p.isSneaking() || !sl.hasPoint(p)) sl.save(p);
        else sl.load(p);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (sl.isItem(e.getItemDrop().getItemStack())) e.setCancelled(true);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        e.getDrops().removeIf(sl::isItem);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) sl.syncItem(p);
        }, 2L);
    }

    /** Không cho cất vật phẩm vào rương/lò/... (khi đang mở inventory khác túi đồ của mình). */
    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (e.getView().getTopInventory().getType() == InventoryType.CRAFTING) return;
        ItemStack hot = null;
        if (e.getHotbarButton() >= 0 && e.getWhoClicked() instanceof Player p) {
            hot = p.getInventory().getItem(e.getHotbarButton());
        }
        if (sl.isItem(e.getCurrentItem()) || sl.isItem(e.getCursor()) || sl.isItem(hot)) e.setCancelled(true);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getType() == InventoryType.CRAFTING) return;
        if (sl.isItem(e.getOldCursor())) e.setCancelled(true);
    }
}
