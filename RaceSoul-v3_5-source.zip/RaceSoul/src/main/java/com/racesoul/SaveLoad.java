package com.racesoul;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Đỏ (Quyết Tâm): kỹ năng SAVE / LOAD. Lưu 1 điểm (vị trí, máu, thức ăn) rồi quay lại sau. */
public final class SaveLoad {
    private static final class Point {
        Location loc;
        double health;
        int food;
        float saturation;
        long expire; // 0 = không hết hạn
    }

    private final SoulPlugin plugin;
    private final Map<UUID, Point> points = new HashMap<>();
    private final NamespacedKey itemKey;

    public SaveLoad(SoulPlugin plugin) {
        this.plugin = plugin;
        this.itemKey = new NamespacedKey(plugin, "save_star");
        // Mỗi giây: hiện ngôi sao SAVE cho chủ điểm lưu, dọn điểm hết hạn / đổi linh hồn
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    public void clear(UUID id) {
        points.remove(id);
    }

    /** Có điểm SAVE còn hạn không. */
    public boolean hasPoint(Player p) {
        Point pt = points.get(p.getUniqueId());
        if (pt == null) return false;
        if (pt.expire > 0 && System.currentTimeMillis() > pt.expire) {
            points.remove(p.getUniqueId());
            return false;
        }
        return true;
    }

    // ===================== Vật phẩm Ngôi sao SAVE =====================

    public ItemStack createItem() {
        ItemStack it = new ItemStack(Material.NETHER_STAR);
        ItemMeta m = it.getItemMeta();
        m.displayName(Component.text("Ngôi sao SAVE", NamedTextColor.RED)
                .decoration(TextDecoration.ITALIC, false));
        m.lore(List.of(
                Component.text("Chuột phải: SAVE (chưa có điểm) / LOAD (đã có điểm)", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Shift + chuột phải: SAVE lại điểm mới", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)));
        m.getPersistentDataContainer().set(itemKey, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(m);
        return it;
    }

    public boolean isItem(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(itemKey, PersistentDataType.BYTE);
    }

    /** Đỏ: có đúng 1 Ngôi sao SAVE. Không phải Đỏ (hoặc tắt give-item): gỡ hết. Gọi lại bao nhiêu lần cũng được. */
    public void syncItem(Player p) {
        boolean want = plugin.getSoul(p) == Soul.RED && !plugin.isRolling(p) && cfg().getBoolean("red.save-load.give-item", true);
        PlayerInventory inv = p.getInventory();
        ItemStack[] arr = inv.getContents();
        int found = 0;
        for (int i = 0; i < arr.length; i++) {
            if (!isItem(arr[i])) continue;
            if (!want || found >= 1) inv.setItem(i, null);
            else found++;
        }
        if (want && found == 0) {
            if (!inv.addItem(createItem()).isEmpty()) {
                p.sendMessage(Component.text("Túi đầy, chưa nhận được Ngôi sao SAVE. Dọn chỗ rồi gõ /linhhon item.",
                        NamedTextColor.RED));
            }
        }
    }

    public void save(Player p) {
        if (p.isDead()) return;
        if (plugin.onCooldown(p, "red-save")) return;
        Point pt = new Point();
        pt.loc = p.getLocation();
        pt.health = p.getHealth();
        pt.food = p.getFoodLevel();
        pt.saturation = p.getSaturation();
        int keep = cfg().getInt("red.save-load.save-expire-seconds", 300);
        pt.expire = keep > 0 ? System.currentTimeMillis() + keep * 1000L : 0L;
        points.put(p.getUniqueId(), pt);
        plugin.setCd(p, "red-save", cfg().getInt("red.save-load.save-cooldown-seconds", 15));

        p.sendActionBar(Component.text("SAVE", NamedTextColor.YELLOW));
        p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.6f);
        p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0, 1, 0), 20, 0.3, 0.6, 0.3, 0.05);
        p.sendMessage(Component.text("Đã SAVE tại đây. Chuột phải Ngôi sao SAVE lần nữa để quay lại.", NamedTextColor.YELLOW));
    }

    public void load(Player p) {
        if (p.isDead()) return;
        Point pt = points.get(p.getUniqueId());
        if (pt == null || (pt.expire > 0 && System.currentTimeMillis() > pt.expire)) {
            points.remove(p.getUniqueId());
            p.sendMessage(Component.text("Bạn chưa có điểm SAVE nào (hoặc đã hết hạn). Chuột phải Ngôi sao SAVE để lưu.", NamedTextColor.RED));
            return;
        }
        if (pt.loc.getWorld() == null) {
            points.remove(p.getUniqueId());
            return;
        }
        if (cfg().getBoolean("red.save-load.same-world-only", true) && !pt.loc.getWorld().equals(p.getWorld())) {
            p.sendMessage(Component.text("Điểm SAVE ở thế giới khác, không thể LOAD từ đây.", NamedTextColor.RED));
            return;
        }
        if (plugin.onCooldown(p, "red-load")) return;
        plugin.setCd(p, "red-load", cfg().getInt("red.save-load.load-cooldown-seconds", 90));

        p.getWorld().spawnParticle(Particle.REVERSE_PORTAL, p.getLocation().add(0, 1, 0), 30, 0.3, 0.6, 0.3, 0.2);
        p.teleport(pt.loc);
        p.setFallDistance(0f);
        p.setFireTicks(0);
        p.setVelocity(new org.bukkit.util.Vector(0, 0, 0));

        // Máu: chỉ hồi lên tới mức đã lưu, không bao giờ bị trừ xuống thấp hơn hiện tại
        if (cfg().getBoolean("red.save-load.restore-health", true)) {
            AttributeInstance mx = p.getAttribute(Attribute.MAX_HEALTH);
            double cap = mx == null ? 20.0 : mx.getValue();
            double target = Math.min(cap, Math.max(pt.health, p.getHealth()));
            p.setHealth(Math.max(1.0, target));
        }
        if (cfg().getBoolean("red.save-load.restore-food", true)) {
            p.setFoodLevel(Math.max(p.getFoodLevel(), pt.food));
            p.setSaturation(Math.max(p.getSaturation(), pt.saturation));
        }
        if (cfg().getBoolean("red.save-load.consume-on-load", true)) points.remove(p.getUniqueId());

        p.sendActionBar(Component.text("LOAD", NamedTextColor.RED));
        p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 0.8f);
        p.getWorld().spawnParticle(Particle.REVERSE_PORTAL, p.getLocation().add(0, 1, 0), 30, 0.3, 0.6, 0.3, 0.2);
    }

    private void tick() {
        if (points.isEmpty()) return;
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, Point>> it = points.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Point> en = it.next();
            Player p = Bukkit.getPlayer(en.getKey());
            Point pt = en.getValue();
            if (p == null || plugin.getSoul(p) != Soul.RED) {
                it.remove();
            } else if (pt.expire > 0 && now > pt.expire) {
                p.sendActionBar(Component.text("Điểm SAVE đã hết hạn", NamedTextColor.GRAY));
                it.remove();
            } else if (pt.loc.getWorld() != null && pt.loc.getWorld().equals(p.getWorld())) {
                p.spawnParticle(Particle.END_ROD, pt.loc.clone().add(0, 1, 0), 2, 0.2, 0.5, 0.2, 0.01);
            }
        }
    }
}
